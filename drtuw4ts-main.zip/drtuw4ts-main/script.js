let i,b;
i=3;
b=5;
alert(i+b);